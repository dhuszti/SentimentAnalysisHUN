package mokk.nlp.ocamorph;

public enum Compounds {
	No, Allow
}
