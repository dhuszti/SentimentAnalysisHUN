package mokk.nlp.ocamorph;

public enum Guess {
	NoGuess, Fallback, Global
}
