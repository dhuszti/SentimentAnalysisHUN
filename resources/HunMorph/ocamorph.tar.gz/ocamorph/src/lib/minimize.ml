

let minimize trie = 
  trie

let compact  trie chars char_count = 
  trie
	  
	




