type token =
  | EOL
  | EOF
  | NODEINFO of (Constraint.morph StringTrie.S.t ref * StringTrie.S.key * StringTrie.S.key * Parser_common.cap * Constraint.flags)
  | TAG of (Tag.chunk)

open Parsing;;
let _ = parse_error;;
# 2 "dic_parser.mly"
 
module G = Constraint

module MorphHash = Hashtbl.Make(struct type t = Parser_common.cap * Tag.chunk * Constraint.flags let equal (c,t,f) (c', t',f') = c = c' && t == t' && f == f' let hash = Hashtbl.hash end)

let morph_hash = ref None

let get_morph_hash () =
  match !morph_hash with Some(x) -> x 
  | None -> let hash = MorphHash.create 100001 in
    morph_hash := Some(hash); 
    hash
       
let reset_morph_hash () = 
  match !morph_hash with None -> () | Some(hash) ->
    Utils.carp 1 "%d morphs\n" (MorphHash.length hash);
    morph_hash := None
	  
let count = ref 0

let insert morphs = function Constraint.Morph( cap, tag, node, clip, flag, flags, char_constraints ) as morph ->
  let morph_hash = get_morph_hash () in
  let key = cap, tag, flags in
  let morph = 
    try 
      incr count;
      MorphHash.find morph_hash key 
    with Not_found ->
      MorphHash.add morph_hash key morph;
      Utils.carp 2 "%d\n" !count;
      morph
  in
  morphs := morph :: !morphs
	
let flag_f = 
  let flag0 = ref None in
  fun () ->
    match !flag0 with Some(x) -> x
    | None ->
	let f = Constraint.Alt [!Parser_common.pseudoroot_flag] in
	flag0 := Some f;
	f

let global_empty_tag = ""
let global_empty_set = []

# 57 "dic_parser.ml"
let yytransl_const = [|
  257 (* EOL *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  258 (* NODEINFO *);
  259 (* TAG *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\002\000\002\000\003\000\003\000\000\000"

let yylen = "\002\000\
\001\000\003\000\002\000\001\000\002\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\001\000\000\000\007\000\000\000\006\000\000\000\
\000\000\005\000\002\000"

let yydgoto = "\002\000\
\005\000\006\000\008\000"

let yysindex = "\255\255\
\001\000\000\000\000\000\255\254\000\000\002\255\000\000\001\255\
\001\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\004\255\000\000\000\000\000\000\005\255\
\000\000\000\000\000\000"

let yygindex = "\000\000\
\254\255\000\000\000\000"

let yytablesize = 259
let yytable = "\001\000\
\003\000\007\000\009\000\010\000\004\000\003\000\011\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\004\000"

let yycheck = "\001\000\
\000\000\003\001\001\001\003\001\001\001\001\001\009\000\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\002\001"

let yynames_const = "\
  EOL\000\
  EOF\000\
  "

let yynames_block = "\
  NODEINFO\000\
  TAG\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    Obj.repr(
# 56 "dic_parser.mly"
      ( reset_morph_hash () )
# 179 "dic_parser.ml"
               : unit))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'rule) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : unit) in
    Obj.repr(
# 57 "dic_parser.mly"
                ()
# 187 "dic_parser.ml"
               : unit))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Constraint.morph StringTrie.S.t ref * StringTrie.S.key * StringTrie.S.key * Parser_common.cap * Constraint.flags) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'tag) in
    Obj.repr(
# 60 "dic_parser.mly"
               ( 
  let (trie, key, skip, cap, flags) = _1 in
  let tag = _2 in
  let tag = if tag = "" then global_empty_tag else tag in
  let clip = None in
  let flag = 0 in (* lexes belong to flag 0 group by default *)
  let char_constraints = global_empty_set in
  let morph = Constraint.Morph( cap, tag, skip, clip, flag, flags, char_constraints ) in
  trie := StringTrie.S.add key morph !trie
)
# 204 "dic_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Constraint.morph StringTrie.S.t ref * StringTrie.S.key * StringTrie.S.key * Parser_common.cap * Constraint.flags) in
    Obj.repr(
# 70 "dic_parser.mly"
           ( 
  let (trie, key, skip, cap, flags) = _1 in
  let tag = global_empty_tag in
  let clip = None in
  let flag = 0 in (* lexes belong to flag 0 group by default *)
  let char_constraints = global_empty_set in
  let morph = Constraint.Morph( cap, tag, skip, clip, flag, flags, char_constraints ) in
  trie := StringTrie.S.add key morph !trie
)
# 219 "dic_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'tag) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Tag.chunk) in
    Obj.repr(
# 81 "dic_parser.mly"
          ( _1 ^ _2 )
# 227 "dic_parser.ml"
               : 'tag))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Tag.chunk) in
    Obj.repr(
# 82 "dic_parser.mly"
      ( _1 )
# 234 "dic_parser.ml"
               : 'tag))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : unit)
