type token =
  | AFFIX of (string)
  | BOOL of (string)
  | FLAG of (int)
  | CLIP of (int)
  | COUNT of (int)
  | EOL
  | EOF
  | COND of (Constraint.morph StringTrie.S.t ref * StringTrie.S.key * StringTrie.S.key * string option * (Constraint.chars option list) * Parser_common.cap)
  | NODEINFO of (string*Constraint.flags)
  | TAG of (Tag.chunk)

open Parsing;;
let _ = parse_error;;
# 2 "aff_parser.mly"
 
module G = Constraint
(*
let flag_f = 
  let flag_f_ref = ref None in
  fun () ->
    match !flag_f_ref with 
    | None ->
	let f1 = !Parser_common.pseudoroot_flag in
	let f2 = !Parser_common.lemma_present in
	let f = Constraint.Alt [f1;f2] in
	flag_f_ref := Some f;
	f
    | Some f -> f
	 *)
# 32 "aff_parser.ml"
let yytransl_const = [|
  262 (* EOL *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* AFFIX *);
  258 (* BOOL *);
  259 (* FLAG *);
  260 (* CLIP *);
  261 (* COUNT *);
  263 (* COND *);
  264 (* NODEINFO *);
  265 (* TAG *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\002\000\002\000\003\000\003\000\000\000"

let yylen = "\002\000\
\001\000\003\000\005\000\006\000\002\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\001\000\007\000\000\000\000\000\000\000\
\000\000\002\000\000\000\000\000\006\000\000\000\005\000"

let yydgoto = "\002\000\
\005\000\006\000\014\000"

let yysindex = "\255\255\
\001\000\000\000\255\254\000\000\000\000\253\254\000\255\001\000\
\254\254\000\000\001\255\252\254\000\000\002\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\003\255\000\000\004\255\000\000"

let yygindex = "\000\000\
\004\000\000\000\000\000"

let yytablesize = 258
let yytable = "\001\000\
\004\000\007\000\008\000\009\000\013\000\011\000\000\000\012\000\
\003\000\004\000\015\000\010\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\003\000"

let yycheck = "\001\000\
\000\000\003\001\006\001\004\001\009\001\008\001\255\255\007\001\
\006\001\006\001\009\001\008\000\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\001\001"

let yynames_const = "\
  EOL\000\
  EOF\000\
  "

let yynames_block = "\
  AFFIX\000\
  BOOL\000\
  FLAG\000\
  CLIP\000\
  COUNT\000\
  COND\000\
  NODEINFO\000\
  TAG\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    Obj.repr(
# 29 "aff_parser.mly"
      (  )
# 166 "aff_parser.ml"
               : unit))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'rule) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : unit) in
    Obj.repr(
# 30 "aff_parser.mly"
                ()
# 174 "aff_parser.ml"
               : unit))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 4 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 3 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : string*Constraint.flags) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : Constraint.morph StringTrie.S.t ref * StringTrie.S.key * StringTrie.S.key * string option * (Constraint.chars option list) * Parser_common.cap) in
    Obj.repr(
# 33 "aff_parser.mly"
                                 ( 
  let flag = _2 in
  let _,flags = _4 in 
  (* this should contain capitalization info which should be counted with *)
  let trie, key, skip, clip, char_constraints, cap = _5 in
  let tag = Tag.top in (* the most uninformative tag e.g., "" or <> *)
  let morph = Constraint.Morph( cap, tag, skip, clip, flag, flags, char_constraints ) in
  trie := StringTrie.S.add key morph !trie
)
# 193 "aff_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 4 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : int) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : string*Constraint.flags) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : Constraint.morph StringTrie.S.t ref * StringTrie.S.key * StringTrie.S.key * string option * (Constraint.chars option list) * Parser_common.cap) in
    let _6 = (Parsing.peek_val __caml_parser_env 0 : 'tag) in
    Obj.repr(
# 42 "aff_parser.mly"
                                    ( 
  let flag = _2 in
  let _, flags = _4 in 
  let trie, key, skip, clip, char_constraints, cap = _5 in
  let tag = _6 in
  let morph = Constraint.Morph( cap, tag, skip, clip, flag, flags, char_constraints ) in
  trie := StringTrie.S.add key morph !trie
)
# 212 "aff_parser.ml"
               : 'rule))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'tag) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Tag.chunk) in
    Obj.repr(
# 52 "aff_parser.mly"
          ( Tag.add_field _1 _2 )
# 220 "aff_parser.ml"
               : 'tag))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Tag.chunk) in
    Obj.repr(
# 53 "aff_parser.mly"
      ( _1 )
# 227 "aff_parser.ml"
               : 'tag))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : unit)
