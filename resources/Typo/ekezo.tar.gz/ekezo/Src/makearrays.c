/*
 **
 ** makearrays.c
 ** copyleft Andras Kornai and Gabor Toth 
 ** March 1997
 **
 ** A sorted.dat alapja1n elke1szi1ti az 
 ** e1kezet-szo1ta1rat e1s az ehhez tartozo1 indexta1bla1t
 **
 */

/****************************************************************************
 * Fejfa1jlok
 ****************************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/****************************************************************************
 * Makro1k
 ****************************************************************************/

#define ALPHABETSIZE 26
#define CUBED 17576      /* 26 a ko2bo2n */
#define MAXWORDLEN 256
#define POOL 160000	 /* wc -l sorted.dat -na1l to2bb */

struct WA                /* szo1 e1s e1kezet */
{
char * w;
unsigned int a;          /* az e1kezetek darabja 2 bit, max 16 lehet */
};

/****************************************************************************
 * Globa1lis va1ltozo1k (fo3ke1pp a la1ncok cso1csa1la1sa1hoz)
 ****************************************************************************/

char inword1[MAXWORDLEN/2-1];
char inword2[MAXWORDLEN/2-1];
char munge[MAXWORDLEN];
char sepchar=':';
char threelet[4];
int curline=0;

/****************************************************************************
 * Vegyes fu2ggve1nyek
 ****************************************************************************/

int usage() 
{
  puts("Haszna1lat: makearrays < sorted.dat");
  puts("Eredme1ny: index.c, e1k.c");
  exit(1);
}

int threehash(char * w)
{
  int hash=0;
  
  hash=*w++ - 'a';
  hash=26*hash + (*w++ - 'a');
  hash=26*hash + (*w - 'a');
  return(hash);
}

char * stralloc(char * s)        /* malloc la1ncoknak */
{
  char * p;

  if ((p = malloc((unsigned)(strlen(s)+1))) != NULL)
    {
      strcpy(p, s);
      return(p);
    }
  else fprintf(stderr,"Nincs to2bb la1ncnak hely\n");
  exit(6);
}

int ParseLine()
{
  int i;

  if((gets(munge))==NULL) return(EOF);
  i=(strchr(munge,sepchar)-munge)-3;
  strncpy(threelet,munge,3);
  strncpy(inword1,munge+3,i);
  *(inword1+i)='\0';
  strcpy(inword2,munge+4+i);
  return(curline++);
}

/****************************************************************************
 * Fo3program
 ****************************************************************************/

main()
{
  struct WA inneracc[POOL];	/* belso3 e1kezet to2mb */
  int innerind[CUBED][2];	/* belso3 index to2mb */
  int i,j,curhash;
  char curthree[4]="000";
  FILE * indf;
  FILE * accf;
	/* kii1rjuk az eleju2ket */

  if((indf = fopen("index.c","w")) != NULL)
      fprintf(indf,"extern int outind[%d+1][2] ={",CUBED);
  if((accf = fopen("e1k.c","w")) != NULL)
      fprintf(accf,"struct WA {char * w;unsigned int a;};\n extern struct WA oute1k[] ={");

  for(i=0;i<CUBED;i++) innerind[i][0]=innerind[i][1]=0;
  for(i=0;i<POOL;i++) inneracc[i].a=0;

	/* kisza1moljuk a ko2zepu2ket */

  curhash=0;
  while((i=ParseLine())!=EOF)
    {
      inneracc[i].w=strdup(inword1);
      for(j=0;j<strlen(inword2);j++)
	inneracc[i].a|=(((*(inword2+j))-'0')<<(2*j));  

      if(threehash(threelet)==curhash) innerind[curhash][1]++;
      else
	{
	  curhash=threehash(threelet);
	  innerind[curhash][0]=i;
	}
    }

	/* kii1rjuk a ko2zepu2ket */

  for(j=0;j<curline;j++)
    fprintf(accf,"{\"%s\",%d},\n",inneracc[j].w,inneracc[j].a);

  for(j=0;j<CUBED;j++)
    fprintf(indf,"{%d,%d},\n",innerind[j][0],innerind[j][1]);
  
	/* kii1rjuk a ve1gu2ket */

  fprintf(accf,"{\"A\",0}};\n");
  fprintf(indf,"{%d,0}};\n",CUBED);
exit(0);
}
