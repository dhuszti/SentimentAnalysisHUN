/*
 **
 ** nagy.c
 ** copyleft Andras Kornai and Gabor Toth 
 ** March 1997
 **
 ** A szavakat a nagyszo1ta1r (e1k.o e1s index.o) alapja1n e1kezi
 **
 */

/****************************************************************************
 * Fejfa1jlok
 ****************************************************************************/

#include <strings.h>
#include <stdio.h>
#include <stdlib.h>

/****************************************************************************
 * Makro1k
 ****************************************************************************/

#define ALPHABETSIZE 26
#define CUBED 17576      /* 26 a ko2bo2n */
#define MAXWORDLEN 256
#define POOL 160000	 /* wc -l sorted.dat -na1l to2bb */
#define BUFSIZE 4096     /* standard bufferolt I/O */
#define ENDTRUNC 4       /* szo1ve1gro3l maximum leva1gott betu3k */

struct WA                /* szo1 e1s e1kezet */
{
const char * w;
unsigned int a;          /* az e1kezetek darabja 2 bit, max 16 lehet */
};

/****************************************************************************
 * Globa1lis va1ltozo1k (fo3ke1pp a la1ncok cso1csa1la1sa1hoz)
 ****************************************************************************/

extern struct WA oute1k[POOL+1];	/* ku2lso3 e1kezet to2mb */
extern int outind[CUBED+1][2];	        /* ku2lso3 index to2mb */

char inword[MAXWORDLEN/2-1];	/* bemeno3 szo1 kisbetu3si1tve */
char capinword[MAXWORDLEN/2-1];	/* az eredeti i1ra1smo1dban */
char truncword[MAXWORDLEN/2-1];
char outword[MAXWORDLEN];
char threelet[4];

int curhash=CUBED+1;		/* kurrens hash e1rte1k */
int currange=0;			/* kurrens cellahossz */
int len=0;                      /* kurrens szo1hossz */
int retcode;			/* az Acc fu2ggve1nyekhez */

int vowelarray[128]={-2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                      -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                      -1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                      1,0,1,1,1,0,1,1,1,0,1,1,1,1,1,0,
                      1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,
                      1,0,1,1,1,0,1,1,1,0,1,1,1,1,1,0,
                      1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,-1};

/****************************************************************************
 * Vegyes fu2ggve1nyek
 ****************************************************************************/

int usage() 
{
  puts("Haszna1lat: nagy < infile >outfile");
  exit(1);
}

int threehash(char * w)
{
  int hash=0;
  
  hash=*w++ - 'a';
  hash=26*hash + (*w++ - 'a');
  hash=26*hash + (*w - 'a');
  return(hash);
}

int CompByW(const void * word, const void * elem)
{
return(strcmp( (char *) word, ((struct WA *)elem)->w));
}

int CompByWn(const void * word, const void * elem)
{
extern int len;
return(strncmp( (char *) word, ((struct WA *)elem)->w, len));
}

unsigned int AccOfWord(char * word, int * rc)
{
  struct WA * kp;
  struct WA * base;
  int i,j,vowdiff;

  curhash=threehash(threelet);
  currange=outind[curhash][1];
  base=&oute1k[outind[curhash][0]];
  len=strlen(word);

				/* elo3szo2r a szo1t keressu2k */
  if((kp=(struct WA *)bsearch(word,base,
			      currange,sizeof(struct WA),&CompByW))!=NULL)
    {
      *rc=0;
      return(kp->a);
    }
				/* azta1n ENDTRUNC-szor levagdossuk */
  for(i=0,vowdiff=15; i <= ENDTRUNC && len>2; i++,--len)
    if((kp=(struct WA *)bsearch(word,base,
				currange,sizeof(struct WA),&CompByWn))!=NULL)
      {
	for(j=0;j<len+3;j++) if(!vowelarray[inword[j]]) vowdiff--;
	for(j=len;j<len+i;j++) if(!vowelarray[kp->w[j]]) vowdiff++;
	*rc=i;
	return(((kp->a)<<(2*vowdiff))>>(2*vowdiff));
      }
				/* azta1n feladjuk */
  *rc=-1;
  return(0);
}

int AddAcc(unsigned int acc)
{     /* capinword-bo3l veszi, outword-be teszi, trunc-nyit mello3z */
  int i,j,k;
  unsigned int locacc;

  for(i=j=k=0;i<strlen(inword);i++)
    {
      outword[j]=capinword[i]; j++;
      if(vowelarray[capinword[i]]) continue;
      else if(locacc=(acc>>2*k)&0x3)
	{
	  switch (locacc) {
	  case 1:
	    outword[j]='1';
	    break;
	  case 2:
	    outword[j]='2';
	    break;
	  case 3:
	    outword[j]='3';
	    break;
	  default: 
	    fprintf(stderr, "Bizarr hiba: %d e1kezet\n",locacc);
	  }
	  j++;k++;
	}
      else k++;
    }
  outword[j]='\0';
  return(k);
}    

/****************************************************************************
 * Fo3program
 ****************************************************************************/

main()
{
  int i,j,c;
  int curline= 0;
  int curhash=-1;
  char curthree[4]="000";
  
  while((c=getchar())!=EOF)
    {				/* az e1rdektelen re1szeket a1tnyomjuk */
      if(c=='\n') curline++;
      if(c!='{') {putchar(c); continue;}
				/* ide csak { uta1n jutunk */
      i=0;
      while((c=getchar())!='}') 
	{
	  capinword[i]=c;
	  inword[i]=tolower(c);
	  i++;
	}
      inword[i]=capinword[i]='\0';
      threelet[0]=inword[0];
      threelet[1]=inword[2];
      threelet[2]=inword[4];
      truncword[0]=inword[1];
      truncword[1]=inword[3];
      strcpy(truncword+2,inword+5);

      j=AccOfWord(truncword,&retcode);
      if(retcode==-1) strcpy(outword,capinword);	/* nem tala1ltuk */
      else AddAcc(j);
      fputs(outword,stdout);
      continue;
    }
  return(0);
}



