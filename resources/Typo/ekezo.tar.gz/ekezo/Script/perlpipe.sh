Src/perl_elo3|Src/perl_gyak|Src/perl_ro2vid|Src/perl_nagy|Src/perl_uto1
